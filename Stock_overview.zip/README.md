## Wordpress custom plugin ##

This is custom wordpress plugin for Stock API
