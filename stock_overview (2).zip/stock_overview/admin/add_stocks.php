<?php include('header.php'); 

global $wpdb,$table_prefix;


if(isset($_POST["submit"])){
		

		echo $filename=$_FILES["file"]["tmp_name"];
		

		 if($_FILES["file"]["size"] > 0)
		 {

		  	$file = fopen($filename, "r");
	         while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
	         {

	         	echo "<pre>";
	         	print_r($emapData);
	         	echo "<pre>";
	    
	         //  //It wiil insert a row to our subject table from our csv file`
	         //   $sql = "INSERT into subject (`SUBJ_CODE`, `SUBJ_DESCRIPTION`, `UNIT`, `PRE_REQUISITE`,COURSE_ID, `AY`, `SEMESTER`) 
	         //    	values('$emapData[1]','$emapData[2]','$emapData[3]','$emapData[4]','$emapData[5]','$emapData[6]','$emapData[7]')";



	         // //we are using mysql_query function. it returns a resource on true else False on error
	         //  $result = mysqli_query( $conn, $sql );
			// 	if(! $result )
			// 	{
			// 		echo "<script type=\"text/javascript\">
			// 				alert(\"Invalid File:Please Upload CSV File.\");
			// 				window.location = \"index.php\"
			// 			</script>";
				
			// 	}

	         }
	        /* fclose($file);
	         //throws a message if data successfully imported to mysql database from excel file
	         echo "<script type=\"text/javascript\">
						alert(\"CSV File has been successfully Imported.\");
						window.location = \"index.php\"
					</script>";
	        
			 

			 //close of connection
			mysqli_close($conn); */
				
		 	
			
		 }
	}	


?>

<div class="container-fluid p-5">
	<div class="row">
		<h5 class="text-primary ">Add Stocks</h5><hr class="mb-4">

		<div class="col-lg-5 col-md-5 col-sm-12">
			<h5>Import Through File</h5>
			<form action="" method="post" enctype="multipart/form-data" class="shadow-sm p-4">
				<div class="row  mt-3">
					<div class="col-12">
						<label for="">Upload File</label>
						<input type="file" class="form-control" name="file" id="file" >
					</div>					
				</div>
				<div class="row mt-3">
					<div class="col-12">
						<input type="submit" id="submit" name="submit" class="btn btn-success" value="Submit">
					</div>					
				</div>
			</form>
		</div>




		<div class="col-lg-7 col-md-7 col-sm-12 ">
			<h5>Add Manual</h5>
            <form action="" method="post" enctype="multipart/form-data" class="shadow-sm p-4 ">
				<div class="row  mt-3">
					<div class="col-6">
						<label for="">Name</label>
						<input type="text" class="form-control" name="name">
					</div>
					<div class="col-6">
						<label for="">Symbol</label>
						<input type="text" class="form-control" name="symbol">
					</div>					
				</div>

				<div class="row  mt-3">
					<div class="col-6">
						<label for="">Content</label>
						<input type="text" class="form-control" name="content">
					</div>
					<div class="col-6">
						<label for="">Test Area</label>
						<input type="text" class="form-control" name="test_area">
					</div>					
				</div>

				<div class="row  mt-3">
					<div class="col-6">
						<label for="">Country</label>
						<input type="text" class="form-control" name="country">
					</div>
					<div class="col-6">
						<label for="">IPO Year</label>
						<input type="text" class="form-control" name="ipo_year">
					</div>					
				</div>

				<div class="row  mt-3">
					<div class="col-6">
						<label for="">Sector</label>
						<input type="text" class="form-control" name="sector">
					</div>
					<div class="col-6">
						<label for="">Industry</label>
						<input type="text" class="form-control" name="industry">
					</div>					
				</div>


				<div class="row mt-3">
					<div class="col-2">
						<input type="submit" name="submit_2" class="btn btn-success" value="Submit">
					</div>
					<div class="col-2">
						<button type="reset" class="btn btn-danger shadow-none">Reset</button>
					</div>				
				</div>
			</form>

		</div>

	</div>
</div>

<?php include('footer.php'); ?>