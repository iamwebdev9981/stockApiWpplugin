<?php include('header.php'); ?>

<div class="container-fluid p-4">
	<h5>Welcome to Manage Stocks</h5><hr>
</div>


<?php include('footer.php'); ?>