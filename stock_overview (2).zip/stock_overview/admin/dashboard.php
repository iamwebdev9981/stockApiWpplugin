<?php include('header.php'); ?>

<div class="container-fluid p-4">
	<h5>WELCOME TO DASHBOARD</h5><hr>
</div>


<?php include('footer.php'); ?>

