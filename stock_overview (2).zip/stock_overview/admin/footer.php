	<!-- Added custom js file -->
	<script src="<?php echo PLUGIN_URL.'/stock_overview/admin/js/custom.js'?>"></script>
</body>
</html>
