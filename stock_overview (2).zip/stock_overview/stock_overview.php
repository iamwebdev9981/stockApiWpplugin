<?php 
/*

* Plugin Name: Stock Overview 
* Description: This is Custom Plugin for Stock Overview By Stock API
* Version: 1.0.0
* Author: GMS
* Author URI: http://localhost/wp_test/

*/

define('PLUGINS_DIR_PATH',plugin_dir_path(__FILE__));
define("PLUGIN_URL",plugins_url());

// for security 
if(!defined('ABSPATH')){
    header("Location:/wp_test");
    die();
}

function stock_plugin_activate(){

  global $wpdb,$table_prefix;
   $wp_stock_overview = $table_prefix.'stock_overview';
  
  $qry1 = "CREATE TABLE IF NOT EXISTS $wp_stock_overview(`id` INT(11) NOT NULL AUTO_INCREMENT , `symbol` VARCHAR(255) NOT NULL , `content` VARCHAR(255) NOT NULL , `name` TEXT NOT NULL , `test_area` TEXT NOT NULL , `country` VARCHAR(255) NOT NULL , `ipo_year` INT(11) NOT NULL , `sector` VARCHAR(255) NOT NULL , `industry` VARCHAR(255) NOT NULL , `status` INT(11) NOT NULL , `add_on` TIMESTAMP NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
   ";
 $wpdb->query($qry1);

}
register_activation_hook(__FILE__, 'stock_plugin_activate');

// CREATE TABLE IF NOT EXISTS $wp_stock_overview(`id` INT NOT NULL AUTO_INCREMENT , `symbol` VARCHAR(255) NOT NULL , `content` TEXT NOT NULL , `name` VARCHAR(255) NOT NULL , `test_area` INT NOT NULL , `country` VARCHAR(255) NOT NULL , `ipo_year` INT NOT NULL , `sector` VARCHAR NOT NULL , `industry` VARCHAR NOT NULL , `status` INT NOT NULL , `add_on` TIMESTAMP NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

// CREATE TABLE `wp_test`.`stocks_overview` (`id` INT(11) NOT NULL AUTO_INCREMENT , `symbol` VARCHAR(255) NOT NULL , `content` VARCHAR(255) NOT NULL , `name` TEXT NOT NULL , `test_area` TEXT NOT NULL , `country` VARCHAR(255) NOT NULL , `ipo_year` INT(11) NOT NULL , `sector` VARCHAR(255) NOT NULL , `industry` VARCHAR(255) NOT NULL , `status` INT(11) NOT NULL , `add_on` TIMESTAMP NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;


function stock_plugin_deactivation(){
    global $wpdb,$table_prefix;
    $wp_stock_overview = $table_prefix.'stock_overview';

    $qry1 = "TRUNCATE $wp_stock_overview";
    $wpdb->query($qry1);
}
register_deactivation_hook(__FILE__, 'stock_plugin_deactivation');


function stock_menu()
{

 add_menu_page( 'Stock Overview', 'Stock Overview', 'manage_options', 'dashboard',  'stock_dashboard_page_load');
 add_submenu_page('dashboard', 'Settings', 'Add Stocks', 'manage_options', 'add_stocks', 'add_stocks_page_load');

 add_submenu_page('dashboard', 'Settings', 'Manage Stocks', 'manage_options', 'manage_stocks', 'manage_stocks_page_load');

 add_submenu_page('dashboard', 'Settings', 'Settings', 'manage_options', 'settings', 'stock_api_page_load');
}
add_action('admin_menu','stock_menu');


function stock_dashboard_page_load()
{
	include('admin/dashboard.php');
}

function add_stocks_page_load()
{
    include('admin/add_stocks.php');
}

function manage_stocks_page_load()
{
	include('admin/manage_stocks.php');
}

function stock_api_page_load()
{
	include('admin/settings.php');
}




function stock_plugin_demo($atts) {
	$Content = "<style>\r\n";
	$Content .= "h3.demoClass {\r\n";
	$Content .= "color: #26b158;\r\n";
	$Content .= "}\r\n";
	$Content .= "</style>\r\n";
	//$Content .= include('admin/list_local_server_movies.php');

    return $Content;
}

add_shortcode('stock-plugin-demo', 'stock_plugin_demo');


 ?>